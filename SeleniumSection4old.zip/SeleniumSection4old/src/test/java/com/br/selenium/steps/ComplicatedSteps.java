package com.br.selenium.steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ComplicatedSteps {

  WebDriver driver;
    public void openURL() {
        System.setProperty("webdriver.chrome.driver","C:\\Users\\kharitonovae\\IdeaProjects\\SeleniumSection4old\\src\\test\\resources\\chromedriver.exe");
        driver = new ChromeDriver();

        driver.get("https://epostaltest.billing.com/tf/AutoPostage/authenticateLogon?cz=6001515040202&tidx=73w5562gazkgzdtqwrptawsrh91qpqqxg1mp5hvq$bxr7fjcfls65hww8rlks7t4f");

    }

    public void enterusrname(String username) {
    }
}
