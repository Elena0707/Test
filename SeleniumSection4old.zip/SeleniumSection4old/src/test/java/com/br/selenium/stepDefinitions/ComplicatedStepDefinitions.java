package com.br.selenium.stepDefinitions;
import com.br.selenium.steps.ComplicatedSteps;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;


public class ComplicatedStepDefinitions {

    @Steps
    ComplicatedSteps complicatedSteps;

    @Given("^the brower is already launched Qa Complicated URL$")
    public void theBrowerIsAlreadyLaunchedQaComplicatedURL() {
        complicatedSteps.openURL();
    }

    @When("user enters the username as {string}")
    public void userEntersTheUsernameAs(String username) {
        complicatedSteps.enterusrname(username);
    }

    @And("user enters the password as {string}")
    public void userEntersThePasswordAs(String arg0) {
    }

    @And("user clicks on the Login button")
    public void userClicksOnTheLoginButton() {
    }

    @Then("verify it launches the login screen")
    public void verifyItLaunchesTheLoginScreen() {
    }

    @And("verify the error with the test {string} is displayed")
    public void verifyTheErrorWithTheTestIsDisplayed(String arg0) {
    }
};