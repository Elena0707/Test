package com.br.selenium.pages;

import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.support.FindBy;

public class ComplicatedPage extends PageObject {
    @FindBy(xpath = "//*[@id=\"user_login_628baeaf9029b]")
    public WebElementFacade username;
    @FindBy(xpath = "//*[@id=\"user_pass_628baeaf95ef0\"]")
    public WebElementFacade Password;
    @FindBy(xpath = "//*[@id=\"post-579\"]/div/div[1]/div/div/div[7]/div[2]/div[5]/div[2]/form/p[4]/button")
    public WebElementFacade login;
}
