package com.br.selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import static java.lang.System.*;

public class WebDriverFactory {
    public static WebDriver findBrowser(String browser) {
        WebDriver WebDriver = null;

        ChromeDriver webDriver = null;
        if (browser.contentEquals("chrome")) {
            System.setProperty("webdriver.chrome.driver","C:\\Users\\kharitonovae\\IdeaProjects\\SeleniumSection4old\\src\\test\\resources\\chromedriver.exe");
            webDriver = new ChromeDriver();

        } else if (browser.contentEquals("ie")) {
            webDriver = new ChromeDriver();
        }
        switch (browser) {
            case "chrome":
            case "ie":
            case "firefox":
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + browser);
        }
        return webDriver;
    }

}