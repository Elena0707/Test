package com.br.selenium.testRunner;

import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.CucumberSerenityRunner;
import org.junit.runner.RunWith;

import io.cucumber.junit.CucumberOptions;
        import io.cucumber.junit.CucumberSerenityRunner;
        import org.junit.runner.RunWith;

@RunWith(CucumberSerenityRunner.class)
@CucumberOptions(
        features = {"C:\\Users\\kharitonovae\\IdeaProjects\\SeleniumSection4old\\src\\test\\resources\\features\\QA-complicated.feature"},
        glue = {"com.br.selenium.stepDefinitions"}
)
public class Runner {


}